package com.example.calculater1

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var input1 : TextView? = null
    private var input2 : TextView? = null
    private var answer : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

            input1 = findViewById(R.id.input1)
            input2 = findViewById(R.id.input2)
            answer = findViewById(R.id.tvAnswer)

            val addBtn = findViewById<Button>(R.id.addBtn)
            val subBtn = findViewById<Button>(R.id.subBtn)
            val mulBtn = findViewById<Button>(R.id.mulBtn)
            val divBtn = findViewById<Button>(R.id.divBtn)
            val sqrBtn = findViewById<Button>(R.id.sqrBtn)
            val powBtn = findViewById<Button>(R.id.powBtn)
            val statBtn = findViewById<Button>(R.id.statBtn)

            addBtn.setOnClickListener {
                add()
            }

            subBtn.setOnClickListener {
                subtract()
            }

            mulBtn.setOnClickListener {
                multiply()
            }

            divBtn.setOnClickListener {
                divide()
            }

            sqrBtn.setOnClickListener {
                squareRoot()
            }

            powBtn.setOnClickListener {
                power()
            }

            statBtn.setOnClickListener {
                statistics()
            }


    }


    private fun add(){

        if(isNotEmpty()){

            val input1 = input1?.text.toString().trim().toBigDecimal()
            val input2 = input2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.add(input2).toString()
        }
    }

    private fun isNotEmpty(): Boolean {
        var isValid = true
        if(input1?.text.toString().trim().isEmpty()){

            input1?.error = "Required"
            isValid = false
        }

        if (input2?.text.toString().trim().isEmpty()){

            input2?.error = "Required"
            isValid = false
        }
        return isValid
    }

    private fun subtract(){

        if(isNotEmpty()){

            val input1 = input1?.text.toString().trim().toBigDecimal()
            val input2 = input2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.subtract(input2).toString()
        }
    }

    private fun multiply(){

        if(isNotEmpty()){

            val input1 = input1?.text.toString().trim().toBigDecimal()
            val input2 = input2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.multiply(input2).toString()
        }

    }

    private fun divide(){

        if (isNotEmpty()){

            val input1 = input1?.text.toString().trim().toBigDecimal()
            val input2 = input2?.text.toString().trim().toBigDecimal()

            if (input2 != BigDecimal.ZERO){

                val result = input1.divide(input2)
                answer?.text = result.toString()
            }
            else {
                answer?.text = "Cannot divide by zero"
            }
        }

    }

    private fun squareRoot(){

    }

    private fun power(){

    }

    private fun statistics(){

    }
}